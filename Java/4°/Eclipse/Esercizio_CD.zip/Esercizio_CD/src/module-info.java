module Esercizio_CD {
}