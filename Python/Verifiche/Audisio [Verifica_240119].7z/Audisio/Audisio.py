#Mattia Audisio 4C
import xml.etree.ElementTree as ET
import json

persona=ET.Element("persona")
tree=ET.ElementTree(persona)
root=tree.getroot()

z = json.load(open("Audisio.json"))
#INDENTO IL FILE XML	
def indent(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i		
#CREO IL FILE XML
nomeUtente=z["nome"]
nome=ET.SubElement(persona,"nome")
nome.text=nomeUtente
bbb=z["telefono"][0]["tipo"]
if bbb=='ufficio':	
	telefono=ET.SubElement(persona,"telefono")
	telefono.set("tipo",bbb)
	telefono.text=z["telefono"][0]["numero"]		
ccc=z["telefono"][1]["tipo"]
if ccc=='cellulare':
	telefono=ET.SubElement(persona,"telefono")
	telefono.set("tipo",ccc)
	telefono.text=z["telefono"][1]["numero"]
	numtelefono=z["telefono"][1]["numero"]			
controllo=z["email"]
if len(controllo)!=0:			
	email=ET.SubElement(persona,"email")
	mailcasa=z["email"]["casa"]
	controllo2=mailcasa
	if len(controllo2)!=0:	
		casa=ET.SubElement(email,"casa")
		casa.text=controllo2
	controllo3=z["email"]["lavoro"]
	if len(controllo3)!=0:	
		casa=ET.SubElement(email,"lavoro")
		casa.text=controllo3
#CREO IL FILE CSV
f=open("Audisio.csv","w")
f.write("nome,numcell,mail\n")
f.close()

indent(root)	
tree.write("Audisio.xml")				
